from flask import Blueprint, request, jsonify
import stripe
import json
from datetime import datetime, timedelta
from src.models.user import User, db

billing_bp = Blueprint('billing', __name__)

# Mock Stripe configuration
stripe.api_key = "sk_test_mock_key"

@billing_bp.route('/billing/plans', methods=['GET'])
def get_subscription_plans():
    """Get available subscription plans"""
    plans = {
        'free_trial': {
            'name': 'Free Trial',
            'price': 0,
            'duration': '14 days',
            'features': [
                '5 designs per month',
                'Basic templates',
                'Standard support',
                'Local weather integration'
            ],
            'limitations': {
                'designs_per_month': 5,
                'templates': 'basic',
                'support': 'email',
                'automation': False
            }
        },
        'single_location': {
            'name': 'Single Location',
            'price': 29,
            'duration': 'per month',
            'features': [
                'Unlimited designs',
                'All templates',
                'Priority support',
                'Full location intelligence',
                'Basic automation',
                'Review integration',
                'Social media scheduling'
            ],
            'limitations': {
                'locations': 1,
                'designs_per_month': 'unlimited',
                'automation': 'basic',
                'white_label': False
            }
        },
        'multi_location': {
            'name': 'Multi-Location',
            'price': 99,
            'duration': 'per month',
            'features': [
                'Everything in Single Location',
                'Up to 10 locations',
                'Advanced automation',
                'Campaign management',
                'Performance analytics',
                'API access',
                'Custom branding'
            ],
            'limitations': {
                'locations': 10,
                'automation': 'advanced',
                'api_access': True,
                'white_label': False
            }
        },
        'white_label': {
            'name': 'White Label Agency',
            'price': 199,
            'duration': 'per month',
            'features': [
                'Everything in Multi-Location',
                'Unlimited locations',
                'White-label branding',
                'Client management',
                'Reseller dashboard',
                'Custom domain',
                'Priority support'
            ],
            'limitations': {
                'locations': 'unlimited',
                'white_label': True,
                'reseller': True
            }
        }
    }
    
    return jsonify(plans)

@billing_bp.route('/billing/subscribe', methods=['POST'])
def create_subscription():
    """Create a new subscription"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        plan_id = data.get('plan_id')
        payment_method = data.get('payment_method')
        
        user = User.query.get_or_404(user_id)
        
        # Mock subscription creation
        subscription = {
            'subscription_id': f"sub_{user_id}_{plan_id}",
            'user_id': user_id,
            'plan_id': plan_id,
            'status': 'active',
            'current_period_start': datetime.utcnow().isoformat(),
            'current_period_end': (datetime.utcnow() + timedelta(days=30)).isoformat(),
            'created_at': datetime.utcnow().isoformat()
        }
        
        # Update user subscription
        user.subscription_plan = plan_id
        user.subscription_status = 'active'
        user.subscription_end_date = datetime.utcnow() + timedelta(days=30)
        db.session.commit()
        
        return jsonify({
            'message': 'Subscription created successfully',
            'subscription': subscription
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@billing_bp.route('/billing/usage/<int:user_id>', methods=['GET'])
def get_usage_stats(user_id):
    """Get usage statistics for a user"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Mock usage data
        usage = {
            'user_id': user_id,
            'current_period': {
                'start_date': datetime.utcnow().replace(day=1).isoformat(),
                'end_date': (datetime.utcnow().replace(day=1) + timedelta(days=32)).replace(day=1).isoformat(),
                'designs_created': 23,
                'templates_used': 8,
                'automation_runs': 15,
                'api_calls': 156
            },
            'plan_limits': {
                'designs_per_month': 'unlimited' if user.subscription_plan != 'free_trial' else 5,
                'templates': 'all' if user.subscription_plan != 'free_trial' else 'basic',
                'automation': user.subscription_plan in ['multi_location', 'white_label'],
                'api_access': user.subscription_plan in ['multi_location', 'white_label']
            },
            'overage_charges': 0,
            'next_billing_date': user.subscription_end_date.isoformat() if user.subscription_end_date else None
        }
        
        return jsonify(usage)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@billing_bp.route('/billing/invoices/<int:user_id>', methods=['GET'])
def get_invoices(user_id):
    """Get billing history for a user"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Mock invoice data
        invoices = [
            {
                'invoice_id': 'inv_001',
                'date': '2025-06-01',
                'amount': 29.00,
                'status': 'paid',
                'plan': 'Single Location',
                'period': 'June 2025'
            },
            {
                'invoice_id': 'inv_002',
                'date': '2025-05-01',
                'amount': 29.00,
                'status': 'paid',
                'plan': 'Single Location',
                'period': 'May 2025'
            },
            {
                'invoice_id': 'inv_003',
                'date': '2025-04-01',
                'amount': 0.00,
                'status': 'paid',
                'plan': 'Free Trial',
                'period': 'April 2025'
            }
        ]
        
        return jsonify(invoices)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@billing_bp.route('/billing/payment-methods/<int:user_id>', methods=['GET'])
def get_payment_methods(user_id):
    """Get saved payment methods for a user"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Mock payment methods
        payment_methods = [
            {
                'id': 'pm_001',
                'type': 'card',
                'card': {
                    'brand': 'visa',
                    'last4': '4242',
                    'exp_month': 12,
                    'exp_year': 2026
                },
                'is_default': True
            }
        ]
        
        return jsonify(payment_methods)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@billing_bp.route('/billing/cancel-subscription', methods=['POST'])
def cancel_subscription():
    """Cancel a subscription"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        user = User.query.get_or_404(user_id)
        user.subscription_status = 'cancelled'
        db.session.commit()
        
        return jsonify({
            'message': 'Subscription cancelled successfully',
            'cancellation_date': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@billing_bp.route('/billing/print-services', methods=['POST'])
def order_print_services():
    """Order print services with 20% commission"""
    try:
        data = request.get_json()
        
        order = {
            'order_id': f"print_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            'user_id': data.get('user_id'),
            'design_id': data.get('design_id'),
            'print_options': {
                'quantity': data.get('quantity', 100),
                'paper_type': data.get('paper_type', 'standard'),
                'size': data.get('size', '8.5x11'),
                'finish': data.get('finish', 'matte')
            },
            'pricing': {
                'base_cost': data.get('quantity', 100) * 0.15,
                'commission': data.get('quantity', 100) * 0.15 * 0.20,
                'total': data.get('quantity', 100) * 0.15 * 1.20
            },
            'shipping': {
                'address': data.get('shipping_address'),
                'method': data.get('shipping_method', 'standard'),
                'estimated_delivery': (datetime.utcnow() + timedelta(days=5)).isoformat()
            },
            'status': 'processing',
            'created_at': datetime.utcnow().isoformat()
        }
        
        return jsonify(order), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

