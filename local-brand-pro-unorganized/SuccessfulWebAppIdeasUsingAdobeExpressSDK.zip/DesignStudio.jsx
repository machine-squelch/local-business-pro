import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Palette, 
  Wand2, 
  Download, 
  Share2, 
  Settings,
  MapPin,
  Star,
  Calendar,
  Thermometer,
  Building2,
  Search,
  Filter,
  Sparkles
} from 'lucide-react'

export default function DesignStudio() {
  const [selectedTemplate, setSelectedTemplate] = useState(null)
  const [selectedIndustry, setSelectedIndustry] = useState('plumbing')
  const [selectedLocation, setSelectedLocation] = useState('austin-tx')
  const [isAdobeExpressLoaded, setIsAdobeExpressLoaded] = useState(false)
  const adobeContainerRef = useRef(null)

  // Mock data for templates
  const industries = [
    { id: 'plumbing', name: 'Plumbing', icon: '🔧' },
    { id: 'automotive', name: 'Automotive', icon: '🚗' },
    { id: 'restaurant', name: 'Restaurant', icon: '🍽️' },
    { id: 'salon', name: 'Beauty Salon', icon: '💄' },
    { id: 'fitness', name: 'Fitness', icon: '💪' },
    { id: 'retail', name: 'Retail', icon: '🛍️' }
  ]

  const templates = {
    plumbing: [
      { id: 1, name: 'Emergency Service Flyer', type: 'Flyer', preview: '/api/placeholder/300/400', seasonal: true },
      { id: 2, name: 'Social Media Post', type: 'Social', preview: '/api/placeholder/300/300', trending: true },
      { id: 3, name: 'Business Card', type: 'Print', preview: '/api/placeholder/300/200', popular: true },
      { id: 4, name: 'Service Menu', type: 'Menu', preview: '/api/placeholder/300/400', new: true }
    ],
    automotive: [
      { id: 5, name: 'Oil Change Special', type: 'Promotion', preview: '/api/placeholder/300/400', seasonal: true },
      { id: 6, name: 'Instagram Story', type: 'Social', preview: '/api/placeholder/300/500', trending: true },
      { id: 7, name: 'Service Reminder', type: 'Postcard', preview: '/api/placeholder/300/200', popular: true }
    ],
    restaurant: [
      { id: 8, name: 'Menu Design', type: 'Menu', preview: '/api/placeholder/300/400', popular: true },
      { id: 9, name: 'Happy Hour Promo', type: 'Social', preview: '/api/placeholder/300/300', trending: true },
      { id: 10, name: 'Table Tent', type: 'Print', preview: '/api/placeholder/300/200', new: true }
    ]
  }

  const localInsights = {
    'austin-tx': {
      weather: 'Sunny, 85°F',
      trending: ['Summer specials', 'AC maintenance', 'Pool services'],
      demographics: 'Young professionals, families',
      events: ['SXSW', 'Austin Food Festival', 'Local farmers markets']
    }
  }

  // Simulate Adobe Express SDK integration
  useEffect(() => {
    if (selectedTemplate && adobeContainerRef.current) {
      // In a real implementation, this would initialize the Adobe Express SDK
      setIsAdobeExpressLoaded(true)
      
      // Mock Adobe Express interface
      adobeContainerRef.current.innerHTML = `
        <div style="
          width: 100%; 
          height: 600px; 
          background: linear-gradient(135deg, #1a1a1a 0%, #2d1b69 50%, #1a1a1a 100%);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-family: system-ui;
          position: relative;
          overflow: hidden;
        ">
          <div style="text-align: center; z-index: 2;">
            <div style="font-size: 24px; font-weight: bold; margin-bottom: 16px;">
              🎨 Adobe Express Design Studio
            </div>
            <div style="font-size: 16px; opacity: 0.8; margin-bottom: 24px;">
              Editing: ${templates[selectedIndustry]?.find(t => t.id === selectedTemplate)?.name || 'Template'}
            </div>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
              <div style="padding: 8px 16px; background: rgba(255,255,255,0.1); border-radius: 6px; font-size: 14px;">
                ✨ AI Auto-customize
              </div>
              <div style="padding: 8px 16px; background: rgba(255,255,255,0.1); border-radius: 6px; font-size: 14px;">
                📍 Austin, TX elements
              </div>
              <div style="padding: 8px 16px; background: rgba(255,255,255,0.1); border-radius: 6px; font-size: 14px;">
                ⭐ Reviews integrated
              </div>
            </div>
          </div>
          <div style="
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><defs><pattern id=\"grid\" width=\"10\" height=\"10\" patternUnits=\"userSpaceOnUse\"><path d=\"M 10 0 L 0 0 0 10\" fill=\"none\" stroke=\"rgba(255,255,255,0.1)\" stroke-width=\"0.5\"/></pattern></defs><rect width=\"100\" height=\"100\" fill=\"url(%23grid)\"/></svg>');
            opacity: 0.3;
          "></div>
        </div>
      `
    }
  }, [selectedTemplate, selectedIndustry])

  const handleTemplateSelect = (templateId) => {
    setSelectedTemplate(templateId)
  }

  const currentTemplates = templates[selectedIndustry] || []
  const currentInsights = localInsights[selectedLocation] || {}

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Design Studio</h1>
          <p className="text-muted-foreground">
            Create professional designs powered by Adobe Express with local intelligence and industry expertise.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Template Selection */}
          <div className="lg:col-span-1 space-y-6">
            {/* Industry Selection */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Industry</CardTitle>
                <CardDescription>Choose your business type</CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {industries.map((industry) => (
                      <SelectItem key={industry.id} value={industry.id}>
                        {industry.icon} {industry.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Location Selection */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Location</CardTitle>
                <CardDescription>Your business location</CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="austin-tx">📍 Austin, TX</SelectItem>
                    <SelectItem value="houston-tx">📍 Houston, TX</SelectItem>
                    <SelectItem value="dallas-tx">📍 Dallas, TX</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Local Insights */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Local Insights</CardTitle>
                <CardDescription>AI-powered local recommendations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2 text-sm">
                  <Thermometer className="h-4 w-4 text-orange-400" />
                  <span>{currentInsights.weather}</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm mb-2">Trending Now</h4>
                  <div className="flex flex-wrap gap-1">
                    {currentInsights.trending?.map((trend, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {trend}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-sm mb-2">Local Events</h4>
                  <div className="space-y-1">
                    {currentInsights.events?.slice(0, 2).map((event, index) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {event}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="templates" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="templates">Templates</TabsTrigger>
                <TabsTrigger value="editor">Design Editor</TabsTrigger>
              </TabsList>

              {/* Templates Tab */}
              <TabsContent value="templates" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">
                    {industries.find(i => i.id === selectedIndustry)?.icon} {industries.find(i => i.id === selectedIndustry)?.name} Templates
                  </h2>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Search templates..." className="pl-9 w-48" />
                    </div>
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {currentTemplates.map((template) => (
                    <Card 
                      key={template.id} 
                      className={`bg-card/50 border-border/50 cursor-pointer transition-all hover:bg-card/80 hover:border-primary/50 ${
                        selectedTemplate === template.id ? 'ring-2 ring-primary border-primary' : ''
                      }`}
                      onClick={() => handleTemplateSelect(template.id)}
                    >
                      <CardHeader className="pb-3">
                        <div className="aspect-[3/4] bg-gradient-to-br from-primary/20 to-primary/5 rounded-lg mb-3 flex items-center justify-center">
                          <Palette className="h-12 w-12 text-primary/60" />
                        </div>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-sm">{template.name}</CardTitle>
                            <CardDescription className="text-xs">{template.type}</CardDescription>
                          </div>
                          <div className="flex flex-col gap-1">
                            {template.seasonal && <Badge className="text-xs bg-orange-500/20 text-orange-400">Seasonal</Badge>}
                            {template.trending && <Badge className="text-xs bg-green-500/20 text-green-400">Trending</Badge>}
                            {template.popular && <Badge className="text-xs bg-blue-500/20 text-blue-400">Popular</Badge>}
                            {template.new && <Badge className="text-xs bg-purple-500/20 text-purple-400">New</Badge>}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="gradient-border">
                          <Button 
                            size="sm" 
                            className="w-full gradient-border-inner"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleTemplateSelect(template.id)
                            }}
                          >
                            <Wand2 className="h-4 w-4 mr-2" />
                            Customize
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* AI Suggestions */}
                <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Sparkles className="h-5 w-5 text-primary" />
                      <CardTitle>AI Suggestions</CardTitle>
                    </div>
                    <CardDescription>
                      Based on your location and industry, we recommend these trending designs
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 rounded-lg bg-background/50 border border-border/30">
                        <h4 className="font-medium text-sm mb-2">Summer AC Special</h4>
                        <p className="text-xs text-muted-foreground mb-3">
                          Perfect for the current Austin heat wave. 45% higher engagement expected.
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          Generate
                        </Button>
                      </div>
                      <div className="p-4 rounded-lg bg-background/50 border border-border/30">
                        <h4 className="font-medium text-sm mb-2">Local Review Showcase</h4>
                        <p className="text-xs text-muted-foreground mb-3">
                          Featuring your latest 5-star reviews with Austin landmarks.
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          Generate
                        </Button>
                      </div>
                      <div className="p-4 rounded-lg bg-background/50 border border-border/30">
                        <h4 className="font-medium text-sm mb-2">Event Promotion</h4>
                        <p className="text-xs text-muted-foreground mb-3">
                          Capitalize on upcoming Austin Food Festival for restaurant clients.
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          Generate
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Editor Tab */}
              <TabsContent value="editor" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Adobe Express Design Editor</h2>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Settings className="h-4 w-4 mr-2" />
                      Settings
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                    <div className="gradient-border">
                      <Button size="sm" className="gradient-border-inner">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Adobe Express Container */}
                <Card className="bg-card/50 border-border/50">
                  <CardContent className="p-6">
                    <div 
                      ref={adobeContainerRef}
                      className="adobe-express-container"
                    >
                      {!selectedTemplate ? (
                        <div className="h-96 flex items-center justify-center text-muted-foreground">
                          <div className="text-center">
                            <Palette className="h-12 w-12 mx-auto mb-4 opacity-50" />
                            <p>Select a template to start designing</p>
                          </div>
                        </div>
                      ) : (
                        <div className="h-96 flex items-center justify-center">
                          <div className="text-center text-muted-foreground">
                            <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                            <p>Loading Adobe Express Editor...</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Design Tools */}
                {selectedTemplate && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="bg-card/50 border-border/50">
                      <CardHeader>
                        <CardTitle className="text-sm">Local Elements</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <MapPin className="h-4 w-4 mr-2" />
                          Add Austin Landmarks
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Building2 className="h-4 w-4 mr-2" />
                          Local Business Info
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Thermometer className="h-4 w-4 mr-2" />
                          Weather Integration
                        </Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-card/50 border-border/50">
                      <CardHeader>
                        <CardTitle className="text-sm">Smart Features</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Star className="h-4 w-4 mr-2" />
                          Import Reviews
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Sparkles className="h-4 w-4 mr-2" />
                          AI Auto-enhance
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Calendar className="h-4 w-4 mr-2" />
                          Seasonal Updates
                        </Button>
                      </CardContent>
                    </Card>

                    <Card className="bg-card/50 border-border/50">
                      <CardHeader>
                        <CardTitle className="text-sm">Export Options</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          Social Media Sizes
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          Print Ready (300 DPI)
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          Web Optimized
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}

