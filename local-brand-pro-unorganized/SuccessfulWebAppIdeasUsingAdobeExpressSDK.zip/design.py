from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Design(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # flyer, social, business_card, etc.
    template_id = db.Column(db.String(50))
    business_id = db.Column(db.Integer, db.ForeignKey('business.id'), nullable=False)
    adobe_express_data = db.Column(db.Text)  # JSON data for Adobe Express
    preview_url = db.Column(db.String(500))
    final_url = db.Column(db.String(500))
    status = db.Column(db.String(20), default='draft')  # draft, published, archived
    design_metadata = db.Column(db.Text)  # JSON metadata (colors, fonts, etc.)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'type': self.type,
            'template_id': self.template_id,
            'business_id': self.business_id,
            'adobe_express_data': self.adobe_express_data,
            'preview_url': self.preview_url,
            'final_url': self.final_url,
            'status': self.status,
            'design_metadata': self.design_metadata,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

