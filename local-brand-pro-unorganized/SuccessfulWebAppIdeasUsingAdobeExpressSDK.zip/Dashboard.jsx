import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  MapPin, 
  Building2, 
  TrendingUp, 
  Star, 
  Calendar,
  Users,
  Palette,
  BarChart3,
  Plus,
  Search,
  Filter
} from 'lucide-react'

export default function Dashboard() {
  const [selectedLocation, setSelectedLocation] = useState('all')
  const [selectedIndustry, setSelectedIndustry] = useState('all')

  // Mock data
  const businessLocations = [
    { id: 1, name: 'Downtown Plumbing', address: '123 Main St, Austin, TX', industry: 'Plumbing', status: 'active' },
    { id: 2, name: 'Westside Auto Repair', address: '456 Oak Ave, Austin, TX', industry: 'Automotive', status: 'active' },
    { id: 3, name: 'Northside Salon', address: '789 Pine St, Austin, TX', industry: 'Beauty', status: 'active' }
  ]

  const recentDesigns = [
    { id: 1, title: 'Summer Plumbing Special', type: 'Social Media Post', created: '2 hours ago', location: 'Downtown Plumbing' },
    { id: 2, title: 'Oil Change Promotion', type: 'Flyer', created: '1 day ago', location: 'Westside Auto Repair' },
    { id: 3, title: 'Holiday Hours Notice', type: 'Instagram Story', created: '2 days ago', location: 'Northside Salon' }
  ]

  const analytics = {
    totalDesigns: 247,
    activeLocations: 3,
    avgEngagement: '12.5%',
    monthlyGrowth: '+23%'
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Business Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your local business designs and track performance across all locations.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Designs</CardTitle>
                <Palette className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalDesigns}</div>
              <p className="text-xs text-muted-foreground">+12 this week</p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active Locations</CardTitle>
                <MapPin className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.activeLocations}</div>
              <p className="text-xs text-muted-foreground">All operational</p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg Engagement</CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.avgEngagement}</div>
              <p className="text-xs text-green-400">+2.3% from last month</p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Growth</CardTitle>
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">{analytics.monthlyGrowth}</div>
              <p className="text-xs text-muted-foreground">Revenue increase</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Business Locations */}
          <div className="lg:col-span-2">
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Business Locations</CardTitle>
                    <CardDescription>Manage your business locations and their design assets</CardDescription>
                  </div>
                  <div className="gradient-border">
                    <Button size="sm" className="gradient-border-inner">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Location
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {businessLocations.map((location) => (
                    <div key={location.id} className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/30">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium">{location.name}</h3>
                          <p className="text-sm text-muted-foreground">{location.address}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge variant="secondary">{location.industry}</Badge>
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                          {location.status}
                        </Badge>
                        <Button variant="ghost" size="sm">
                          Manage
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Designs */}
            <Card className="bg-card/50 border-border/50 mt-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Recent Designs</CardTitle>
                    <CardDescription>Your latest design creations and updates</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Search designs..." className="pl-9 w-48" />
                    </div>
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentDesigns.map((design) => (
                    <div key={design.id} className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/30">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                          <Palette className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium">{design.title}</h3>
                          <p className="text-sm text-muted-foreground">{design.type} • {design.location}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-sm text-muted-foreground">{design.created}</span>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions & Insights */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks and shortcuts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="gradient-border">
                  <Button className="w-full gradient-border-inner justify-start">
                    <Palette className="h-4 w-4 mr-2" />
                    Create New Design
                  </Button>
                </div>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Social Post
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Star className="h-4 w-4 mr-2" />
                  Import Reviews
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  View Analytics
                </Button>
              </CardContent>
            </Card>

            {/* Local Insights */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>Local Market Insights</CardTitle>
                <CardDescription>AI-powered recommendations for your area</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
                  <div className="flex items-start space-x-3">
                    <TrendingUp className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Seasonal Opportunity</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        Summer AC maintenance campaigns are trending 45% higher in Austin this week.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                  <div className="flex items-start space-x-3">
                    <Star className="h-5 w-5 text-green-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Review Highlight</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        You have 3 new 5-star reviews ready to feature in your designs.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <div className="flex items-start space-x-3">
                    <Users className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-sm">Local Event</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        Austin Food & Wine Festival next week - perfect for restaurant promotions.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

